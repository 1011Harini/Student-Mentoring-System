import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Paper, Box, Checkbox, Typography, CircularProgress } from '@mui/material';
import { getAllComplains } from '../../../redux/complainRelated/complainHandle';
import TableTemplate from '../../../components/TableTemplate';

const SeeComplains = () => {
  const dispatch = useDispatch();
  const { complainsList, loading, error, response } = useSelector(state => state.complain);
  const { currentUser } = useSelector(state => state.user);

  useEffect(() => {
    dispatch(getAllComplains(currentUser._id, "Complain"));
  }, [currentUser._id, dispatch]);

  if (error) {
    console.log('Error fetching complains:', error);
  }

  const complainColumns = [
    { id: 'user', label: 'User', minWidth: 170 },
    { id: 'complaint', label: 'Complaint', minWidth: 100 },
    { id: 'date', label: 'Date', minWidth: 170 },
  ];

  const complainRows = complainsList && complainsList.length > 0 && complainsList.map(complain => {
    const date = new Date(complain.date);
    const dateString = !isNaN(date) ? date.toISOString().substring(0, 10) : "Invalid Date";
    return {
      user: complain.user ? complain.user.name : 'Teacher', // Ensure complain.user exists before accessing name
      complaint: complain.complaint || 'No Complaint', // Default value if complaint is undefined
      date: dateString,
      id: complain._id,
    };
  });

  const ComplainButtonHaver = ({ row }) => (
    <Checkbox inputProps={{ 'aria-label': 'Select complain' }} />
  );

  return (
    <>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          {response ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
              <Typography variant="h6">No complains right now.</Typography>
            </Box>
          ) : (
            <Paper sx={{ width: '100%', overflow: 'hidden' }}>
              {Array.isArray(complainsList) && complainsList.length > 0 && (
                <TableTemplate buttonHaver={ComplainButtonHaver} columns={complainColumns} rows={complainRows} />
              )}
            </Paper>
          )}
        </>
      )}
    </>
  );
};

export default SeeComplains;
